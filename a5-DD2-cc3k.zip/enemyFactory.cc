#include "enemyFactory.h"
#include "enemy.h"


EnemyFactory::~EnemyFactory() {}
