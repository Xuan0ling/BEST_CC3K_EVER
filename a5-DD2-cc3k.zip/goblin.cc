#include "goblin.h"

Goblin::Goblin(Floor *floor, PlayerRace race):
    Player(floor, race, 110, 15, 20, 0, 110) {}
    
Goblin::~Goblin() {}

